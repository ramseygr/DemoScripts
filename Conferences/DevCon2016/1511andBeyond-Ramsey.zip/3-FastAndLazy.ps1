﻿
Get-CMSoftwareUpdate -fast | measure | select count

measure-command {Get-CMSoftwareUpdate} | select totalseconds

measure-command {Get-CMSoftwareUpdate -fast} | select totalseconds


Get-CMSoftwareUpdate -fast -Debug | select -first 5

Get-CMSoftwareUpdate -Debug | select -first 5

get-wmiobject -Namespace root\sms\site_ps1 -class sms_softwareupdate | 
    select -first 5
get-wmiobject -Namespace root\sms\site_ps1 `
    -query "select * from sms_SoftwareUpdate" | select -first 5


get-ciminstance -Namespace root\sms\site_ps1 -class sms_softwareupdate | 
    select -first 5 | select ArticleID, SDMPackageXML | foreach {
        $_
    }
    

get-ciminstance -Namespace root\sms\site_ps1 -class sms_softwareupdate | 
    select -first 5 | get-ciminstance | select ArticleID, SDMPackageXML |  
    foreach {
        $_
    }
#Find cmdlets that support fast http://blog.coretech.dk/kaj/configmgr-cmdlets-and-lazy-properties/$module = Get-Command -Module configurationmanager
 
foreach($name in $module.name){
 
    $cmdlet = Get-Command $name
    if($cmdlet.Parameters.ContainsKey('fast')){
        $cmdlet.name
    }
 
}
 

 #Find lazy properties in ConfigMgr: https://trevorsullivan.net/2010/09/28/powershell-configmgr-wmi-provider-feat-lazy-properties/

