﻿#Resources and Collections

help Get-CMResource -full    
show-command Get-CMResource        
get-cmresource -ResourceType System -fast
get-cmresource -ResourceId 16777221 -Fast


Get-CMCollectionMember -CollectionName 'All Desktop and Server Clients' | 
    out-gridview

Get-CMCollectionMember -CollectionName 'All Desktop and Server Clients' | fl 

Get-CMCollectionMember -CollectionName 'All Desktop and Server Clients' | 
    Select Name, ADLastLogonTime, ClientActiveStatus, ClientVersion, `
    CNIsOnline, CNLastOnlineTime, DeviceOS, Domain, LastClientCheckTime, `
    LastDDR, LastHardwareScan, LastMPServerName, LastPolicyRequest, `
    LastSoftwareScan | out-gridview

Get-CMCollectionMember -CollectionName 'All Desktop and Server Clients' | 
    Select-Object Name, ADLastLogonTime, ClientActiveStatus, ClientVersion, `
    CNIsOnline, CNLastOnlineTime, DeviceOS, Domain, LastClientCheckTime, `
    LastDDR, LastHardwareScan, LastMPServerName, LastPolicyRequest, `
    LastSoftwareScan | Export-Csv C:\Scripts\members.csv -NoTypeInformation
notepad C:\Scripts\members.csv

Get-CMCollectionMember -CollectionName 'All Desktop and Server Clients' | 
    Select-Object Name, ADLastLogonTime, ClientActiveStatus, ClientVersion, `
    CNIsOnline, CNLastOnlineTime, DeviceOS, Domain, LastClientCheckTime, `
    LastDDR, LastHardwareScan, LastMPServerName, LastPolicyRequest, `
    LastSoftwareScan | 
    where-object {$_.LastClientCheckTime -le (get-date).AddDays(-2)} |
    Export-Csv C:\Scripts\Unhealthymembers.csv -NoTypeInformation



#Export a collection
Export-CMCollection `
    -ExportFilePath C:\Scripts\DevCon2016\1511AndBeyond\SampleData\MyColl.mof `
    -Name "TestColl1"
explorer.exe C:\Scripts\DevCon2016\1511AndBeyond\SampleData


#Collection Audit
psedit C:\scripts\DevCon2016\1511AndBeyond\CollectionAudit.ps1
Explorer.exe C:\Scripts\StatusFilter\Collections

