﻿New-CMCollection -CollectionType Device -Name 'TestColl3' `
    -LimitingCollectionName 'All Desktop and Server Clients'



$Collection = Get-CMCollection -Name 'TestColl3' -CollectionType Device
$TargetFolder = Get-Item 'PS1:\DeviceCollection\test2'

$Parameters = @{
    ContainerNodeID = 0;
    InstanceKeys = @($Collection.CollectionID)
    ObjectType = $TargetFolder.ObjectType;
    TargetContainerNodeID = $TargetFolder.ContainerNodeID
}

Invoke-CMWmiMethod `
    -ClassName SMS_objectContainerItem `
    -MethodName MoveMembers `
    -Parameter $Parameters


$Coll = Get-CMCollection -Name "TestColl3" -CollectionType Device
Move-CMObject -ObjectId $Coll.CollectionID `
    -FolderPath PS1:\DeviceCollection\test2



#invoke-CMWMIQuery
$wql = 'select Name, ADSiteName, Build, ClientVersion  from sms_r_system'
invoke-cmwmiquery -Query $wql | out-gridview
