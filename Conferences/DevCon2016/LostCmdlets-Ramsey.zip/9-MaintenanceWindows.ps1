﻿#region Maintenance Windows

#Create new Maintenance Window

#Create Collection First
$CollName = 'Test Coll2'
New-CMCollection -CollectionType Device -Name $CollName `
    -LimitingCollectionName 'All Desktop and Server Clients'

#Create new MW Schedule - every Saturday at 2:00AM for 3 Hours
$mwSched = New-CMSchedule -DayOfWeek Saturday -Start ([datetime]"2:00 am") `
    -End ([datetime]"2:00 am").addhours(3) 

New-CMMaintenanceWindow -CollectionName $CollName -Schedule $mwSched `
    -Name "SW Updates MW" -ApplyTo SoftwareUpdatesOnly

#show existing mw
Get-CMMaintenanceWindow -CollectionName $CollName

#task - Show all collections with maintenance windows...
Get-CMMaintenanceWindow
Get-CMMaintenanceWindow -CollectionName '*' -ForceWildcardHandling
Get-CMCollectionSetting -CollectionName '*' -ForceWildcardHandling

Invoke-CMWmiQuery -Query 'SELECT * FROM SMS_CollectionSettings' | `
    where-object {$_.servicewindows -ne $Null} 

Invoke-CMWmiQuery -Query 'SELECT * FROM SMS_CollectionSettings' | `
    where-object {$_.servicewindows -ne $Null} | ForEach-Object {
        $_.CollectionID, $_.ServiceWindows
    }


#Remove MW
Remove-CMMaintenanceWindow -CollectionName $CollName `
    -MaintenanceWindowName "SW Updates MW" -force

#endregion

