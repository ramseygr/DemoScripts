﻿#region Import Module
#HKEY_CURRENT_USER\Software\Microsoft\ConfigMgr10\AdminUI\MRU$CMModulePath = `    $Env:SMS_ADMIN_UI_PATH.ToString().SubString(0,$Env:SMS_ADMIN_UI_PATH.Length - 5) `    + "\ConfigurationManager.psd1" Import-Module $CMModulePath -forceNew-PSDrive -Name 'PS1' -PSProvider 'AdminUI.PS.Provider\CMSite' `    -Root 'gmrcmcbrtm.gmr.net' -Description 'Primary Site'cd PS1:#endregion #region basics#get CM cmdlets
get-command -Module ConfigurationManager | Out-GridView

#show commands for set-cmapplication
show-command Set-CMApplication#Debug - checking under the hoodGet-CMPackage -DebugGet-CMPackage -Debug | select -First 5#endregion#region Wild card handling
Get-CMPackage -Name "Test Package 1" | select Name, PackageidGet-CMPackage -Name "Test Package 1*" | select Name, PackageidGet-CMPackage -Name "Test Package 1*" -DisableWildcardHandling | select Name, PackageidGet-CMPackage -Name "Test Package 1*" -ForceWildcardHandling | select Name, Packageid#endregion #region show -Passthru
#without -PassThru, $app is empty
$App = Set-CMApplication -Name 'Greg Test' -Description 'DevCon'
$App

$App = Set-CMApplication -Name 'Greg Test' -Description 'DevCon2016' -PassThru
$App#endregion 