﻿#region DeviceVariable

#import a computer (as an example)
Import-CMComputerInformation -ComputerName 'GregTest' `    -MacAddress '00:15:5D:01:65:87' -CollectionName 'OSDColl'Invoke-CMCollectionUpdate -Name 'All Systems'Invoke-CMCollectionUpdate -Name 'OSDColl'Get-CMDevice -name 'GregTest' | New-CMDeviceVariable `    -VariableName 'SystemRole' -VariableValue 'Sales'Remove-CMDevice -Name 'GregTest' -Force#endregion