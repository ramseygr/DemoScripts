﻿#region Client Notification
Show-Command Invoke-CMClientNotification

Invoke-CMClientNotification -DeviceName 'GMRDC2' `
    -NotificationType RequestMachinePolicyNow

Invoke-CMClientOperationSummarization

Get-CMClientOperation | Select-Object TargetCollectionName, 
    TotalClients, CompletedClients, FailedClients, 
    UnknonwClients, RequestedTime, 
    LastSummaryTime |Out-GridView

Get-CMClientOperation | 
    where-object {$_.RequestedTime.ToLocalTime() -ge ((get-date).AddHours(-1))} |
    Select-Object TargetCollectionName, TotalClients, CompletedClients, 
    FailedClients, UnknonwClients, RequestedTime, LastSummaryTime |Out-GridView

#Get-CMClientOperation | Remove-CMClientOperation -Force

#endregion


